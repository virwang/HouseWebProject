# Pagination Tables 
add paginattion to any table by using jquery 


# DOC : 

1. Link your website with Bootstrap and jQuery 
2. Link your website with js.js file 
3. on page load function add one of the below functions : 


* getPagination('table');               // to select the table by html tag 

* getPagination('.table-class');       // or if you want to select the table by table class 

* getPagination('#table-id');          // or select the table with table id 



* You can use balanceSize function in $(window).resize() to balance the size on resizing the page 


[ Try the DEMO ](https://codepen.io/yasser-mas/full/pyWPJd)





![alt text](https://github.com/yasser-mas/pagination-tables/blob/master/css/pagination.jpg "Screenshot")
