package tw.house._08_.mail;

import java.util.Random;

public class ActionMail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<5;i++) {
			int num = (int)(Math.random()*10);
			System.out.println(i+":"+num);
			
		}
	}

}
