package tw.house._07_.Email;

public interface EmailService {

	void sendSimpleMessage(String to, String subject, String text);

}