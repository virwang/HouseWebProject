package tw.house._13_.model.dao;

import java.util.List;

import tw.house._13_.model.bean.HouseLoanList;

public interface HouseLoanListIpl {

	public List<HouseLoanList> ShowHouseLoanList ();
	
}
